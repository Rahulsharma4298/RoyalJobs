<?php
//DB 
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "job");
define("SITE_TITLE", "Jobs Finder");

?>