<?php include 'inc/header.php';?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
      <div class="jumbotron" style="background-color: #cce6ff">

        <h1 class="display-3">Find A Job</h1><br>
        <form method="GET" action="index.php" class="form-group">
          <select name="category" class="custom-select">
            <option value="0">Choose Category</option>

            <?php foreach($categories as $category): ?>

              <option value="<?php echo $category->id; ?>"><?php echo $category->name; ?></option>
            <?php endforeach; ?>
        </select><br>

        <!--<p class="lead">Get Your Dream Job or Internship, List Jobs and More. 
        Start Today for Free!</p> !-->

        <br>
        <p><input type="submit" value="FIND" class="btn btn-lg btn-success" href="#" role="button"></input></p>
      </form>
      </div>
      <h3><?php echo $title; ?></h3><br>

      <?php foreach($jobs as $job): ?>

      <div class="row marketing">
        <div class="col-md-10">

          <h4 class=><?php echo $job->job_title; ?></h4> 

          <p><?php echo $job->description; ?></p>
        </div>
          <div class="md-col-2">
          <a class="btn btn-primary" href="job.php?id=<?php echo $job->id ?>">View</a>
          </div>
      </div>
      
        <?php endforeach; ?>
 
</body>
</html>

<?php include 'inc/footer.php';?>