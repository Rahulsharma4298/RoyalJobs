<!DOCTYPE html>
<html>
<head>
</head>
<body><br>
	<div><hr>
	 <footer class="container">
    <p class="float-right"><a href="#">Back to top</a></p>
    <p>© 2017-2019 Company, Inc.</p>
  </footer>
    </div>
</body>
</html>