<?php
	//Redirect to Page
	function redirect($page = FALSE, $message = NULL, $message_type = NULL){
		if(is_string($page)){
			$location = $page;
		}else{
			$location = $_SERVER['SCRIPT_NAME'];
		}

		//Check for Message
		if($message != NULL){
			//Set Message
			$_SESSION['message'] = $message;
		}
		//Check for Type
		if($message_type != NULL){
			//Set Message Type
			$_SESSION['message_type'] = $message_type;
		}

		//Redirect
		header ('Location: '.$location);
		exit;
}

	//Display Message
function displayMessage(){
	if(!empty($_SESSION['message'])){

			//Assign Message Var
		$message = $_SESSION['message'];

		if(!empty($_SESSION['message_type'])){
				//Assign Type Variable
			$message_type = $_SESSION['message_type'];
				//Create Object
			if($message_type == 'error') {
				echo '<div class="alert alert-dismissible alert-danger">
  					<button type="button" class="close" data-dismiss="alert">&times;</button>
  					<strong>' . $message . '</strong></div>';

			} else {
				echo '<div class="alert alert-dismissible alert-success">
  					<button type="button" class="close" data-dismiss="alert">&times;</button>
  					<strong>' . $message . '</strong></div>';
			}
		}
		//Unset Message
		unset($_SESSION['message'] );
		unset($_SESSION['message_type'] );
	}else {
		echo '';
	}
}